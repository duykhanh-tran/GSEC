# Đặc tả chuyển đổi hệ thống AI Tutor sang React

Phiên bản: `approved-9`  
Ngày cập nhật: `06/09/2026`  
Trạng thái: **Giai đoạn 9 — Đạt kỹ thuật; bộ bàn giao cuối đã hoàn tất; chờ người dùng nghiệm thu hệ React**  
Nguồn chuẩn đối chiếu: `Propotype/`  
Đầu ra dự kiến: `Propotype-React/`

## 1. Mục đích tài liệu

Tài liệu này là đặc tả bắt buộc cho việc chuyển hệ thống AI Tutor đã hợp nhất trong `Propotype/` từ HTML/CSS/JavaScript thuần sang React. Mọi quyết định triển khai, kiểm thử và nghiệm thu phải tuân theo tài liệu này.

Không bắt đầu tạo mã React trước khi tài liệu được người dùng xác nhận. Nếu cần thay đổi phạm vi hoặc kiến trúc sau khi tài liệu được duyệt, phải cập nhật phiên bản tài liệu và ghi rõ lý do trước khi tiếp tục.

## 2. Hiện trạng được dùng làm baseline

- Hệ thống chuẩn hiện tại nằm trong `Propotype/`.
- Có 26 task được đăng ký, từ `60111` đến `60155`.
- Mỗi task hiện là một tài liệu HTML độc lập và có `index.html`, `style.css`, `script.js`.
- Mỗi module task xuất `init(root)` và `destroy()`.
- Registry, điều hướng, popup nhập mã và bộ nạp trang đã được tách dùng chung.
- Design token và component avatar/bóng thoại đã được chuẩn hóa theo `foundation-1`.
- Task `60111` là mẫu hình ảnh gốc cho avatar, font và bóng thoại.
- Popup và bàn phím trang Index nhận chính xác 5 chữ số.
- Có 32 file kiểm thử, gồm kiểm thử riêng từng task và kiểm thử hồi quy toàn hệ thống.
- Các task ghi âm/STT hiện là mô phỏng. Hệ thống không dùng `getUserMedia`, `MediaRecorder`, `SpeechRecognition`, backend, `fetch` hoặc cơ chế lưu trữ bền vững.
- Một số task dùng Web Speech `speechSynthesis` để đọc nội dung.
- Ảnh Tutor hiện lấy từ Dropbox và cần kết nối mạng.

Các tài liệu baseline có thẩm quyền:

- `writing-block.md`
- `PROJECT_AUDIT.md`
- `Propotype/README.md`
- `Propotype/source-baseline.json`
- `Propotype/styles/COMPONENT-STANDARD.md`
- `Propotype/js/registry.js`
- `Propotype/tests/`

Khi nội dung giữa tài liệu và mã chạy thực tế khác nhau, phải dừng tại task liên quan, xác minh bằng kiểm thử và xin quyết định trước khi thay đổi hành vi đã nghiệm thu.

## 3. Mục tiêu chuyển đổi

1. Chuyển đủ 26 task `60111`–`60155` sang React.
2. Giữ nguyên nội dung học tập, đáp án, Demo, gợi ý, số lần thử, điểm số, mastery và điều kiện hoàn tất.
3. Giữ giao diện đã chuẩn hóa, đặc biệt avatar, font, bóng thoại, bảng màu và popup 5 số.
4. Thay thao tác DOM trực tiếp bằng component và state React.
5. Tách component, hook và mô hình trạng thái có thể tái sử dụng cho WS6, WS7 và các worksheet sau.
6. Bảo toàn truy cập trực tiếp, refresh, Back, Forward và các mã task hiện tại.
7. Duy trì khả năng đối chiếu tự động giữa hệ HTML và hệ React trong suốt quá trình.
8. Không làm gián đoạn hoặc ghi đè hệ HTML đang hoạt động.

## 4. Ngoài phạm vi

Đợt chuyển đổi này không tự động bao gồm:

- Thiết kế lại giao diện hoặc thương hiệu.
- Thay đổi nội dung tiếng Anh, đáp án hoặc logic sư phạm.
- AI, STT, ghi âm microphone hoặc chấm phát âm thật.
- Backend, tài khoản, cơ sở dữ liệu hoặc lưu tiến độ lên máy chủ.
- Đồng bộ dữ liệu thật giữa các task.
- Chuyển WS6, WS7 hoặc thư mục khác ngoài 26 task đã có trong `Propotype`.
- Xóa, đổi tên, di chuyển hoặc ghi đè các thư mục `WS 1_HTML`–`WS 5_HTML` và `Propotype`.
- Đưa hệ thống lên production khi chưa có yêu cầu triển khai riêng.

Mọi nội dung ngoài phạm vi phải được phê duyệt và lập đặc tả bổ sung.

## 5. Nguyên tắc bảo vệ nguồn

1. `Propotype/` được coi là baseline chỉ đọc trong toàn bộ quá trình React.
2. Các thư mục `WS 1_HTML`–`WS 5_HTML` tiếp tục chỉ dùng để tham chiếu.
3. Toàn bộ mã React phải nằm trong thư mục mới `Propotype-React/`.
4. File đặc tả này nằm tại root project, bên cạnh `Propotype/`.
5. Trước Giai đoạn 1 phải kiểm tra toàn bộ SHA-256 trong `Propotype/source-baseline.json`.
6. Trước mỗi đợt nghiệm thu phải chạy lại kiểm tra hash nguồn.
7. Không dùng lệnh xóa hoặc ghi đè diện rộng trên root project.
8. Mỗi nhóm hoàn tất phải có bản đóng gói độc lập và checksum SHA-256.
9. Nếu React chưa đạt, người dùng luôn có thể tiếp tục sử dụng `Propotype/`.

## 6. Công nghệ được khóa

| Hạng mục | Quyết định |
|---|---|
| UI runtime | React |
| Ngôn ngữ | TypeScript, bật kiểm tra nghiêm ngặt |
| Build tool | Vite |
| Điều hướng | React Router |
| Style | CSS Variables + CSS Modules hoặc stylesheet component có phạm vi rõ ràng |
| State đơn giản | `useState` |
| State nhiều bước | `useReducer` với action/type rõ ràng |
| Side effect | Custom hooks + `useEffect` cleanup đầy đủ |
| Unit/component test | Vitest + React Testing Library |
| E2E/parity test | Playwright |
| Global store | Không dùng Redux ở phạm vi hiện tại |
| HTML động | JSX; không dùng `dangerouslySetInnerHTML` để sao chép task cũ |
| Nội dung | Hằng số TypeScript hoặc cấu hình typed, không tải từ backend |

Không thêm thư viện state, UI hoặc animation mới nếu component/hook nội bộ đáp ứng được yêu cầu. Nếu scaffold có sẵn thư viện UI, chỉ sử dụng khi giữ được giao diện và hợp đồng truy cập hiện tại.

## 7. Kiến trúc thư mục mục tiêu

```text
Propotype-React/
  index.html
  package.json
  package-lock.json
  tsconfig.json
  vite.config.ts

  public/

  src/
    main.tsx

    app/
      App.tsx
      router.tsx
      registry.ts
      task-types.ts

    styles/
      tokens.css
      global.css
      components.css

    components/
      shell/
        AppShell.tsx
        TutorHeader.tsx
        TaskFooter.tsx
      chat/
        TutorAvatar.tsx
        ChatRow.tsx
        TutorBubble.tsx
        StudentBubble.tsx
      keypad/
        CodeKeypad.tsx
        InlineCodeKeypad.tsx
      task/
        TaskCard.tsx
        ActionButton.tsx
        FeedbackBox.tsx
        ResultSummary.tsx
        AnswerGrid.tsx
        RecordingCard.tsx
        TranscriptReview.tsx

    hooks/
      useAutoScroll.ts
      useManagedTimers.ts
      useSpeechSynthesis.ts
      useRecordingSimulation.ts
      useConfetti.ts

    tasks/
      60111/
        Task60111.tsx
        data.ts
        reducer.ts
        task.module.css
      ...
      60155/
        Task60155.tsx
        data.ts
        reducer.ts
        task.module.css

  tests/
    unit/
    components/
    e2e/
    parity/

  scripts/
    generate-legacy-routes.mjs
    verify-source-hashes.mjs
```

Không bắt buộc tạo file `reducer.ts` cho task đơn giản. Không đưa khác biệt chỉ dùng một lần vào component chung nếu chưa có ít nhất hai trường hợp thực tế hoặc lý do kiến trúc rõ ràng.

## 8. Trách nhiệm các tầng

| Tầng | Trách nhiệm |
|---|---|
| `app/` | Router, registry, metadata và xử lý task không tồn tại |
| `styles/` | Token, reset và style nền tảng dùng chung |
| `components/` | Giao diện dùng lại, không chứa đáp án hoặc logic sư phạm riêng |
| `hooks/` | Timer, interval, scroll, speech và animation có cleanup |
| `tasks/<mã>/data.ts` | Câu hỏi, đáp án, Demo, hint, nhãn lỗi và nội dung tĩnh |
| `tasks/<mã>/reducer.ts` | Trạng thái và chuyển trạng thái nghiệp vụ |
| `tasks/<mã>/Task*.tsx` | Kết hợp dữ liệu, state và component để tạo trải nghiệm task |
| `tests/` | Kiểm tra reducer, component, nghiệp vụ, URL và parity |

## 9. Quy tắc component

### 9.1. Component bắt buộc dùng chung

- App shell và vùng nội dung cuộn.
- Header, nút Back, metadata và nút mở keypad.
- Avatar Tutor Dropbox.
- Hàng chat Tutor/học sinh.
- Bóng thoại Tutor/học sinh.
- Popup nhập mã và keypad inline trang Index.
- Footer trạng thái task.
- Button cơ bản và trạng thái disabled.
- Card header/body, feedback, status tag và summary.

### 9.2. Component chỉ tách khi đã xác nhận dùng lại

- Answer matrix/radio grid.
- Retry card nhiều cấp.
- Recording waveform.
- Transcript confirmation.
- Score grid.
- Confetti.
- Transfer/mastery sequence.

### 9.3. Quy tắc JSX và DOM

1. Không dùng `innerHTML`, `insertAdjacentHTML` hoặc `document.write`.
2. Không dùng `dangerouslySetInnerHTML` để đưa nội dung task vào React.
3. Ưu tiên phần tử semantic: `button`, `input`, `label`, `section`, heading đúng cấp.
4. Không truy vấn `document.querySelector` để điều khiển phần tử React.
5. Chỉ dùng `ref` cho focus, scroll, media hoặc đo kích thước thật sự cần thiết.
6. ID phải duy nhất; ưu tiên `useId`, `data-*` và quan hệ component.
7. Giữ các `data-*` selector đã dùng trong Playwright nếu không có lý do buộc phải đổi.
8. Nội dung học tập phải được render dưới dạng text/JSX để React tự escape.

## 10. Design system và parity giao diện

React phải bắt đầu từ các token hiện hành, không tạo theme mới.

Các giá trị bắt buộc giữ:

- `--font-family-ui` là font duy nhất toàn hệ thống.
- Màu primary `#8B0450`.
- Avatar Tutor `34×34px`.
- Tutor bubble: nền `#F1F5F9`, radius `17px 17px 17px 5px`.
- Student bubble: nền `#F9EDF3`, radius `17px 17px 5px 17px`.
- Nội dung bóng thoại: `14px`, line-height `1.45`, padding `10px 12px`.
- Shell rộng tối đa `480px`.
- Popup và keypad phải giữ thiết kế, focus, error, safe area và reduced-motion hiện hành.

Trong giai đoạn chuyển đổi, được phép tái sử dụng token CSS từ `Propotype` bằng bản sao có kiểm soát trong `Propotype-React`; không liên kết runtime trực tiếp sang thư mục baseline.

CSS task chỉ chứa layout hoặc trạng thái thật sự riêng. Không ghi đè avatar, chat row hoặc bubble chuẩn từ CSS task.

## 11. Registry và route

### 11.1. Registry React

Registry phải là nguồn duy nhất ánh xạ:

```text
code → worksheet → task number → title → subtitle → component → legacy URL
```

Mọi mã được typed và kiểm tra trùng khi build/test.

### 11.2. URL chuẩn

URL React chuẩn:

```text
/
/tasks/:code
```

Trang `/` hiển thị trực tiếp keypad 5 số. Route task không tồn tại phải quay về Index và hiện lỗi có mã vừa nhập hoặc hiển thị trang lỗi có đường quay lại rõ ràng.

### 11.3. Tương thích URL cũ

Các URL sau phải tiếp tục mở đúng task:

```text
/?page=60111
/tasks/60111/index.html
...
/tasks/60155/index.html
```

Build production phải tạo route tương thích hoặc các HTML chuyển tiếp được sinh tự động. Không quản lý thủ công 26 bản sao HTML.

Phải kiểm tra URL trực tiếp bằng một static server không có SPA fallback. Không được chỉ xác nhận bằng Vite development server.

### 11.4. Điều hướng

- Popup và Index dùng cùng registry và cùng quy tắc nhập mã.
- Điều hướng trong React dùng router.
- Back, Forward và Refresh phải giữ đúng task.
- Đóng/mở popup phải reset giá trị và lỗi đúng như hệ hiện tại.
- Mã không hợp lệ không được điều hướng.

## 12. Hợp đồng popup 5 số

1. Chính xác 5 ô PIN.
2. Chỉ nhận `0–9`, tối đa 5 chữ số.
3. Hỗ trợ click và bàn phím vật lý.
4. Tự kiểm tra sau khi đủ 5 số.
5. Hỗ trợ Enter, Backspace và Escape.
6. Modal có dialog semantics, focus ban đầu, trả focus và khóa scroll.
7. Lỗi dùng `role="alert"` và hiển thị chính mã không tồn tại.
8. Trang Index dùng biến thể inline, không sao chép logic nhập mã.
9. Timer tự submit phải được hủy khi đóng hoặc unmount.
10. Tất cả 26 mã phải lấy từ registry React.

## 13. Quản lý state và side effect

### 13.1. State

- State task phải nằm trong component hoặc reducer của task đó.
- Không đưa đáp án, hàng đợi câu sai hoặc điểm số vào biến global.
- Không chia sẻ state ngầm giữa các task.
- Task đơn giản dùng `useState`; task nhiều bước dùng reducer với phase/action rõ ràng.
- Mọi trạng thái hoàn tất, guided, retry, transcript và mastery phải có kiểu TypeScript.

### 13.2. Side effect

- Mọi timeout/interval phải đi qua hook quản lý chung.
- Cleanup khi đổi route, unmount hoặc pagehide.
- Speech synthesis phải cancel khi đổi route hoặc unmount.
- Confetti phải dọn node/timer sau khi kết thúc.
- Auto-scroll không được tạo vòng render hoặc cuộn sai khi footer cố định.
- Event bàn phím phải được đăng ký một lần và cleanup đầy đủ.

### 13.3. React StrictMode

Ứng dụng phải chạy an toàn trong StrictMode ở development:

- Không nhân đôi tin nhắn Tutor.
- Không khởi động hai timer hoặc hai recording simulation.
- Không phát âm hai lần.
- Không gắn lặp listener.
- Không cộng điểm hai lần.

Không tắt StrictMode để che lỗi lifecycle.

## 14. Hợp đồng tương tác đặc biệt

### 14.1. Speech synthesis

- Giữ `en-US` và tốc độ tương ứng với task hiện tại.
- Nút Listen có accessible name.
- Cancel lượt đọc trước khi bắt đầu lượt mới.
- Nếu trình duyệt không hỗ trợ, task vẫn phải dùng được và không phát sinh lỗi.

### 14.2. Recording/STT mô phỏng

- Tiếp tục là mô phỏng, không yêu cầu quyền microphone.
- Giữ waveform, timer, transcript Demo, xác nhận và ghi lại.
- Không mô tả hoặc ghi nhãn khiến người dùng hiểu nhầm rằng âm thanh thật đã được lưu.
- Timer phải ổn định trong test và cleanup khi rời route.

### 14.3. Confetti và chuyển động

- Giữ đúng thời điểm hoàn tất đã nghiệm thu.
- Tôn trọng `prefers-reduced-motion`.
- Không để node animation tồn tại sau khi đổi task.

## 15. Ma trận chuyển đổi 26 task

| Task | Nhóm nghiệp vụ chính | Độ phức tạp | Thành phần/rủi ro chính | Thứ tự dự kiến |
|---|---|---:|---|---:|
| `60111` | Input nhiều nhóm, retry, summary | Cao | Input động, hàng đợi lỗi, student bubble, confetti | 26 |
| `60112` | Listening và pronunciation | Cao | TTS, timer, tiến độ, pronunciation simulation | 25 |
| `60113` | Answer grid và retry | Cao | TTS, student bubble, nhiều trạng thái sửa | 24 |
| `60114` | True/False và retry | Cao | TTS, queue câu sai, confetti | 23 |
| `60115` | Writing capture và coaching | Cao | Input, preview, repair, dữ liệu giữa bước | 22 |
| `60116` | Speaking/review | Cao | TTS, recording simulation, timer, feedback | 21 |
| `60121` | Collocation matrix và transfer | Cao | 8 mục, family lỗi, transfer, confetti | 20 |
| `60122` | Meaning MCQ và retry | Trung bình | Answer grid, hai cấp gợi ý | 19 |
| `60123` | Listening và pronunciation | Cao | TTS, timeline, waveform, retry | 18 |
| `60124` | Sentence fluency | Cao | TTS, recording simulation, feedback | 17 |
| `60125` | Transcript và language check | Cao | Timer, xác nhận transcript, phân biệt lỗi | 16 |
| `60126` | Priority review và mastery | Cao | Review queue, mastery gate, score | 15 |
| `60131` | Present Simple input/retry/transfer | Cao | Input typed, normalize, reducer nhiều phase | 2 — pilot |
| `60132` | Form/meaning MCQ | Trung bình | Answer grid, retry hai cấp | 14 |
| `60133` | Frequency position MCQ | Trung bình | Position choices, retry, corrected sentence | 13 |
| `60134` | Frequency meaning | Trung bình | Day strip, answer grid, retry | 12 |
| `60135` | STT grammar check | Cao | Timer, transcript, self-check | 11 |
| `60141` | Functional phrase options | Trung bình | Entry, retry, summary | 10 |
| `60142` | Meaning/appropriacy MCQ | Trung bình | Error labels, repeated retry | 9 |
| `60143` | Supported dialogue/STT | Cao | Nhiều turn, timer, transcript, correction | 8 |
| `60144` | AI role-play | Cao | TTS, reducer nhiều round, recording, mastery | 7 |
| `60151` | Reading main idea | Trung bình | Guided/independent state, multi-level hint | 6 |
| `60152` | Reading details | Trung bình | 6 mục, Guided, queue retry | 5 |
| `60153` | Conversation cohesion | Trung bình | 6 lựa chọn, Guided, queue retry | 4 |
| `60154` | Speaking readiness checklist | Thấp | Toggle, validate, completion gate | 1 — pilot |
| `60155` | AI speaking nhiều vòng | Cao | TTS, three recordings, transcript, revision, mastery | 3 — pilot |

Thứ tự sau ba pilot đi theo WS5 → WS4 → WS3 → WS2 → WS1. Trong từng nhóm vẫn chuyển và nghiệm thu từng task, không chuyển hàng loạt.

## 16. Chiến lược chuyển đổi từng task

Mỗi task phải đi qua đúng trình tự:

1. Đọc `index.html`, `style.css`, `script.js` trong `Propotype/tasks/<mã>/`.
2. Đọc kiểm thử riêng và báo cáo migration của task.
3. Lập bảng state, event, guard, side effect và kết quả cuối.
4. Xác định phần nào dùng component chung và phần nào riêng.
5. Chuyển nội dung tĩnh sang typed data/JSX.
6. Chuyển logic sang state hoặc reducer.
7. Chuyển style riêng sang phạm vi task.
8. Giữ `data-*` selector phục vụ kiểm thử.
9. Chạy unit/reducer test.
10. Chạy E2E riêng của task.
11. So sánh giao diện ở `390×844` và `1024×900`.
12. Chạy hồi quy foundation, bubble, keypad và navigation.
13. Cập nhật ma trận trạng thái.
14. Chỉ bắt đầu task kế tiếp khi task hiện tại đạt toàn bộ cổng nghiệm thu.

## 17. Ba task pilot và mục tiêu

### Pilot 1 — `60154`

Xác nhận shell, router, keypad, chat, checklist, local state, completion gate và summary.

### Pilot 2 — `60131`

Xác nhận input, normalize, answer data, retry queue, multi-stage hint, transfer, reducer và confetti.

### Pilot 3 — `60155`

Xác nhận TTS, timer/interval, recording simulation, transcript confirmation, revision, score, mastery và StrictMode cleanup.

Sau ba pilot phải dừng để đánh giá kiến trúc. Chỉ khi cả ba đạt mới khóa component/hook và chuyển 23 task còn lại.

## 18. Kiểm thử

### 18.1. Baseline HTML

- Hệ HTML chạy ở cổng riêng, mặc định `4173`.
- Trước mỗi nhóm React, test baseline HTML liên quan phải đạt.
- Không cập nhật test HTML để che khác biệt React.

### 18.2. React development và production

- React chạy ở cổng riêng, ví dụ `4174`.
- Test phải chạy cả development và bản production build.
- Production test phải phục vụ thư mục build bằng static server độc lập.

### 18.3. Unit/component test

- Registry không trùng mã và đủ 26 task.
- Reducer có transition hợp lệ và không cho vượt gate.
- Chuẩn hóa đáp án và scoring đúng.
- Timer/speech hooks cleanup đúng.
- Keypad xử lý số, lỗi, reset và keyboard đúng.
- Component giữ semantics và accessibility cơ bản.

### 18.4. E2E theo task

- Initial state.
- Demo state.
- Đáp án sai và từng cấp gợi ý.
- Đáp án đúng.
- Record again/transcript confirmation nếu có.
- Summary, score, Guided và Mastery.
- Điều kiện mở nút cuối.
- Popup 5 số.
- Không có runtime error.

### 18.5. Hồi quy toàn hệ thống

- Đủ 26 route và 26 mã.
- `/`, `?page=`, URL React và URL legacy.
- Back, Forward, Refresh và direct deep link.
- Mã hợp lệ/không hợp lệ.
- Popup và keypad inline.
- Avatar Dropbox đúng URL và đúng khung.
- Bóng thoại khớp chuẩn `60111`.
- Không tràn ngang ở mobile/desktop.
- Không selector task thoát phạm vi.
- Không timer, listener, speech hoặc animation rò rỉ khi đổi route.
- Không lỗi console trong toàn bộ lượt chạy.

## 19. Cổng nghiệm thu từng task

Một task chỉ được đánh dấu **Đạt** khi đáp ứng đồng thời:

- Nội dung và thứ tự màn hình khớp baseline.
- Demo, đáp án và hint khớp baseline.
- Luồng retry/guided/mastery khớp baseline.
- Giao diện đạt ở hai viewport chuẩn.
- Avatar, font và bóng thoại đúng foundation.
- Popup 5 số hoạt động đầy đủ.
- Direct URL, refresh và history hoạt động.
- Không `innerHTML`/`dangerouslySetInnerHTML` cho nội dung task.
- Không side effect bị nhân đôi trong StrictMode.
- Cleanup đầy đủ khi đổi route.
- Unit test đạt.
- E2E task đạt.
- Hồi quy chung đạt.
- Hash nguồn HTML vẫn khớp.

Nếu thiếu một điều kiện, task giữ trạng thái **Chưa đạt** và không chuyển task tiếp theo.

## 20. Cổng nghiệm thu theo giai đoạn

| Giai đoạn | Đầu ra bắt buộc | Điều kiện đi tiếp |
|---:|---|---|
| 0 | `REACT-MIGRATION-SPEC.md` | Người dùng duyệt tài liệu |
| 1 | Baseline hash, test log, gói HTML phục hồi | 26 task HTML đạt |
| 2 | `Propotype-React` scaffold | Dev và production build đạt |
| 3 | Foundation React | Shell, router, keypad, token và accessibility đạt |
| 4 | Ba pilot | `60154`, `60131`, `60155` đạt riêng và chung |
| 5 | Kiến trúc React khóa | Component/hook/state contract được duyệt |
| 6 | 23 task còn lại | Mỗi task đạt trước khi chuyển tiếp |
| 7 | URL compatibility | Direct URL, legacy URL, history và static hosting đạt |
| 8 | Full regression | 26 task đạt dev và production |
| 9 | Gói bàn giao | Báo cáo, checksum, hướng dẫn và rollback đầy đủ |

## 21. Checkpoint và rollback

1. Không thay đổi baseline để sửa lỗi React.
2. Tạo checkpoint sau foundation, sau từng pilot và sau từng WS.
3. Mỗi checkpoint gồm source, test log, build và SHA-256 gói đóng.
4. Nếu test task thất bại, rollback chỉ trong `Propotype-React`, không tác động `Propotype`.
5. Nếu thay đổi component chung làm hỏng task đã đạt, phải sửa hồi quy trước khi tiếp tục task mới.
6. Không chuyển người dùng sang React mặc định trước Giai đoạn 9.
7. Không xóa hệ HTML sau khi React được nghiệm thu; việc lưu trữ/xóa là quyết định riêng của người dùng.

## 22. Quản lý thay đổi

Các thay đổi sau phải được người dùng duyệt trước:

- Thay đổi nội dung, đáp án, Demo hoặc scoring.
- Thay đổi màu, font, avatar, bubble hoặc bố cục chính.
- Bỏ URL cũ hoặc thay quy tắc mã 5 chữ số.
- Thay mô phỏng bằng microphone, STT hoặc AI thật.
- Thêm backend, tài khoản hoặc lưu trữ.
- Thêm framework/state library ngoài danh sách đã khóa.
- Mở rộng sang WS6/WS7.
- Ghi đè hoặc xóa `Propotype`.

Thay đổi kỹ thuật nội bộ không ảnh hưởng hợp đồng trên có thể thực hiện trong task hiện tại nhưng phải được ghi vào báo cáo migration React.

## 23. Báo cáo bắt buộc

Sau mỗi task:

- File React đã tạo/sửa.
- Component/hook dùng lại.
- State và reducer đã chuyển.
- Khác biệt với baseline, nếu có.
- Test đã chạy và kết quả.
- Hash nguồn đã kiểm tra.
- Vấn đề còn tồn tại.

Sau mỗi WS:

- Danh sách task đạt/chưa đạt.
- Hồi quy component chung.
- Kết quả URL/keypad.
- Gói checkpoint và SHA-256.

Khi bàn giao:

- Ma trận đủ 26 task.
- Báo cáo parity HTML/React.
- Hướng dẫn development và production.
- Danh sách giới hạn còn tồn tại.
- Gói source/build cuối và SHA-256.
- Hướng dẫn rollback về `Propotype`.

## 24. Tiêu chí hoàn thành toàn dự án

Dự án React chỉ hoàn thành khi:

1. Đủ 26 task trong registry React.
2. Toàn bộ 26 task đạt cổng nghiệm thu riêng.
3. Toàn bộ test unit, component, E2E, parity và production đạt.
4. URL mới và URL legacy hoạt động trên static server.
5. Không có lỗi runtime hoặc rò rỉ side effect đã biết.
6. Giao diện chuẩn được điều khiển từ component/token chung.
7. Không có task dùng bản sao keypad hoặc chat component riêng.
8. Các file nguồn và `Propotype` không bị thay đổi.
9. Có gói bàn giao, checksum, tài liệu chạy và rollback.
10. Người dùng nghiệm thu bản React.

## 25. Trạng thái Giai đoạn 0

- [x] Xác định mục tiêu và ngoài phạm vi.
- [x] Khóa thư mục đầu ra và quy tắc bảo vệ nguồn.
- [x] Khóa stack React.
- [x] Xác định kiến trúc component, hook, task và test.
- [x] Xác định route chuẩn và tương thích URL cũ.
- [x] Lập ma trận đủ 26 task.
- [x] Xác định ba task pilot.
- [x] Xác định thứ tự chuyển 23 task còn lại.
- [x] Xác định cổng nghiệm thu, checkpoint và rollback.
- [x] Người dùng đọc và xác nhận đặc tả ngày `05/09/2026`.

**Giai đoạn 1 đã được người dùng cho phép bắt đầu ngày `05/09/2026`.**

## 26. Trạng thái Giai đoạn 1

- [x] Kiểm tra 26/26 hash nguồn WS.
- [x] Chạy đủ 32/32 kiểm thử HTML.
- [x] Lưu 54/54 ảnh baseline mobile và desktop.
- [x] Xác nhận không tràn ngang và không có lỗi runtime trong lượt chụp.
- [x] Tạo gói HTML phục hồi và checksum SHA-256.
- [x] Người dùng xác nhận Giai đoạn 1 thành công ngày `05/09/2026`.

## 27. Trạng thái Giai đoạn 2

- [x] Tạo thư mục độc lập `Propotype-React/`.
- [x] Khởi tạo React + Vite + TypeScript strict.
- [x] Tích hợp React Router.
- [x] Cài đặt Vitest, React Testing Library và Playwright.
- [x] Lint và unit smoke test đạt.
- [x] Development server hoạt động ở cổng riêng.
- [x] Production build và production preview đạt.
- [x] Xác minh lại 26/26 nguồn WS và 144/144 file baseline `Propotype`.
- [x] Tạo checkpoint Foundation và checksum SHA-256.

Chi tiết được lưu tại `Propotype-React/STAGE-2-REPORT.md`.

**Giai đoạn 3 được người dùng cho phép bắt đầu ngày `05/09/2026` và hoàn tất nghiệm thu kỹ thuật ngày `06/09/2026`.**

## 28. Trạng thái Giai đoạn 3

- [x] Registry typed đủ 26 mã, không trùng.
- [x] Router chuẩn, query route và legacy route runtime.
- [x] Trang Index dùng keypad 5 số trực tiếp.
- [x] Shell, header, footer và metadata dùng component chung.
- [x] Avatar, hàng chat và bóng thoại Tutor/học sinh dùng component chung.
- [x] Token React khớp HTML `foundation-1`.
- [x] Popup và keypad inline dùng chung logic React.
- [x] Dialog semantics, focus, scroll lock, alert và reduced-motion đạt.
- [x] Lint, 9/9 unit/component test, build và 3/3 E2E đạt.
- [x] Mobile/desktop không tràn ngang và không có console/page error.
- [x] Xác minh lại 26/26 nguồn WS và 144/144 file baseline `Propotype`.

Tài liệu Foundation: `Propotype-React/FOUNDATION-STANDARD.md`.  
Báo cáo nghiệm thu: `Propotype-React/STAGE-3-REPORT.md`.

Tài liệu pilot: `Propotype-React/STAGE-4-REPORT.md` và `Propotype-React/PILOT-ARCHITECTURE-REVIEW.md`.

Tài liệu kiến trúc khóa: `Propotype-React/REACT-ARCHITECTURE-STANDARD.md`.  
Báo cáo nghiệm thu: `Propotype-React/STAGE-5-REPORT.md`.

## 29. Trạng thái Giai đoạn 5.5

- [x] Phân loại đủ 26 task thành 11 archetype có kiểu TypeScript.
- [x] Tạo authoring schema và catalog kiểm tra tự động với registry.
- [x] Tạo `TaskRenderer` và `TaskFlowRenderer`, không rẽ nhánh theo mã task.
- [x] Tạo block chuẩn cho choice matrix, retry, listening, playback sequence,
  recording, transcript, progress, score, mastery, Guided/Independent và celebration.
- [x] Chuyển ba pilot `60131`, `60154`, `60155` qua renderer/config runtime mới.
- [x] Giữ reducer/data riêng và escape hatch `custom` cho ngoại lệ thật.
- [x] Lint, unit/component, build, E2E development/preview và baseline verification đạt.
- [x] Khóa contract `architecture-2`; chưa chuyển 23 task còn lại.

Chi tiết: `Propotype-React/TASK-ARCHETYPE-CATALOG.md`,
`Propotype-React/TASK-AUTHORING-SCHEMA.md` và
`Propotype-React/STAGE-5.5-REPORT.md`.

**Giai đoạn 6 đã được người dùng cho phép và đã hoàn thành ngày `06/09/2026`.**

## 30. Trạng thái Giai đoạn 6

- [x] Chuyển 23 task còn lại theo thứ tự WS5 → WS4 → WS3 → WS2 → WS1.
- [x] Registry ánh xạ tường minh đủ 26/26 mã sang implementation React, không còn fallback `FoundationTaskPage`.
- [x] Tái sử dụng và mở rộng kho component/hook chuẩn thay vì sao chép logic theo task.
- [x] Giữ nguyên selector `data-*`, route, keypad 5 số và Foundation đã khóa.
- [x] Lint, 35/35 unit/component test và production build đạt.
- [x] E2E development đạt đủ 33/33 kịch bản sau khi xác minh lại task sửa cuối.
- [x] E2E production preview đạt 33/33 kịch bản.
- [x] Responsive smoke đủ 26 route đạt ở `1024×900` và `390×844`, không tràn ngang.
- [x] Xác minh lại 26/26 hash nguồn WS và 144/144 hash baseline `Propotype`.
- [x] Tạo báo cáo, manifest, gói checkpoint và SHA-256 phục hồi Giai đoạn 6.

Chi tiết: `Propotype-React/STAGE-6-REPORT.md` và
`Propotype-React/checkpoints/stage-6/`.

**Giai đoạn 7 đã được người dùng cho phép và đã hoàn thành ngày `06/09/2026`.**

## 31. Trạng thái Giai đoạn 7

- [x] Build tự sinh 26 entry point vật lý `dist/tasks/<mã>/index.html`.
- [x] URL chuẩn `/tasks/<mã>` hoạt động và refresh được cho đủ 26 task.
- [x] URL legacy `/tasks/<mã>/index.html` hoạt động và chuẩn hóa về URL React.
- [x] Query URL `/?page=<mã>` hoạt động cho đủ 26 task.
- [x] Back, Forward và Refresh giữ đúng task sau điều hướng bằng keypad 5 số.
- [x] Query code không hợp lệ hiển thị cảnh báo; direct URL không tồn tại trả HTTP 404 và vẫn có đường quay lại.
- [x] Static server nghiêm ngặt không dùng SPA fallback; URL bất kỳ trả HTTP 404.
- [x] E2E static compatibility đạt 3/3.
- [x] Full E2E development đạt 34 bài, 3 bài static-only được bỏ qua đúng thiết kế.
- [x] Full E2E production preview đạt 34 bài, 3 bài static-only được bỏ qua đúng thiết kế.
- [x] Lint, 35/35 unit/component test, build và baseline integrity đạt.
- [x] Tạo báo cáo, manifest, gói checkpoint và SHA-256 phục hồi Giai đoạn 7.

Chi tiết: `Propotype-React/STAGE-7-REPORT.md` và
`Propotype-React/checkpoints/stage-7/`.

**Giai đoạn 8 đã được người dùng cho phép và đã hoàn thành ngày `06/09/2026`.**

## 32. Trạng thái Giai đoạn 8

- [x] Chạy parity audit trực tiếp giữa baseline HTML và React cho đủ 26 task.
- [x] Kiểm tra 52/52 tổ hợp task/viewport tại `390×844` và `1024×900`.
- [x] Lưu 54/54 ảnh nghiệm thu React gồm Index và 26 task ở hai viewport.
- [x] Đối chiếu tiêu đề, phụ đề, nội dung ban đầu, shell, avatar, Tutor bubble và overflow.
- [x] Phát hiện và sửa metadata/nội dung lệch baseline tại `60115`, `60125`, `60126`.
- [x] Parity cuối: 0 sai lệch, 0 runtime/console error; token recall thấp nhất `72,73%`, trung bình `91,52%`.
- [x] Full E2E development đạt 34 bài; 4 bài runner-specific skipped đúng thiết kế.
- [x] Full E2E production preview đạt 34 bài; 4 bài runner-specific skipped đúng thiết kế.
- [x] Static URL compatibility đạt 3/3.
- [x] HTML/React parity runner đạt 1/1.
- [x] Lint, 35/35 unit/component test, production build và baseline integrity đạt.
- [x] Tạo báo cáo, metrics, manifest, checkpoint và SHA-256 Giai đoạn 8.

Chi tiết: `Propotype-React/STAGE-8-REPORT.md`,
`Propotype-React/reports/stage-8-visual/` và
`Propotype-React/checkpoints/stage-8/`.

**Giai đoạn 9 đã được người dùng cho phép và đã hoàn thành ngày `06/09/2026`.**

## 33. Trạng thái Giai đoạn 9

- [x] Lập tài liệu tổng quan bàn giao và phạm vi hệ thống.
- [x] Lập hướng dẫn cài đặt, development, build, static hosting và kiểm thử.
- [x] Lập hướng dẫn rollback an toàn về baseline `Propotype`.
- [x] Lập ma trận nghiệm thu đủ 26/26 task.
- [x] Ghi rõ giới hạn recording/STT, speech synthesis, avatar Dropbox và static hosting.
- [x] Tổng hợp báo cáo parity, 54 ảnh và toàn bộ checkpoint Giai đoạn 8 vào hồ sơ bàn giao.
- [x] Xác minh lại lint, 35/35 unit/component test, build và baseline integrity.
- [x] Tạo final manifest, gói source/build cuối và SHA-256.
- [x] Không thay đổi hoặc xóa hệ HTML và các thư mục WS.

Chi tiết: `Propotype-React/FINAL-HANDOVER.md`,
`Propotype-React/OPERATIONS-RUNBOOK.md`,
`Propotype-React/ROLLBACK-GUIDE.md`,
`Propotype-React/TASK-ACCEPTANCE-MATRIX.md`,
`Propotype-React/KNOWN-LIMITATIONS.md` và
`Propotype-React/deliverables/`.

**Toàn bộ chín giai đoạn kỹ thuật đã hoàn thành. Dự án chờ người dùng nghiệm thu bản React; việc triển khai công khai vẫn cần yêu cầu riêng.**
