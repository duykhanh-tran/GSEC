# Ma trận nghiệm thu 26 task

Tất cả task dưới đây dùng implementation React thật, route chuẩn, URL legacy tĩnh, Foundation chung và đã qua E2E/parity.

| WS | Task | Route React | URL legacy | Nhóm nghiệp vụ | Trạng thái |
|---:|---:|---|---|---|---:|
| 1 | `60111` | `/tasks/60111` | `/tasks/60111/index.html` | Input, retry, summary | Đạt |
| 1 | `60112` | `/tasks/60112` | `/tasks/60112/index.html` | Listening, pronunciation | Đạt |
| 1 | `60113` | `/tasks/60113` | `/tasks/60113/index.html` | Choice matrix, retry | Đạt |
| 1 | `60114` | `/tasks/60114` | `/tasks/60114/index.html` | True/False, retry | Đạt |
| 1 | `60115` | `/tasks/60115` | `/tasks/60115/index.html` | Writing capture, repair | Đạt |
| 1 | `60116` | `/tasks/60116` | `/tasks/60116/index.html` | Speaking simulation, feedback | Đạt |
| 2 | `60121` | `/tasks/60121` | `/tasks/60121/index.html` | Collocation matrix, transfer | Đạt |
| 2 | `60122` | `/tasks/60122` | `/tasks/60122/index.html` | Meaning choices, retry | Đạt |
| 2 | `60123` | `/tasks/60123` | `/tasks/60123/index.html` | Listening, pronunciation | Đạt |
| 2 | `60124` | `/tasks/60124` | `/tasks/60124/index.html` | Sentence fluency | Đạt |
| 2 | `60125` | `/tasks/60125` | `/tasks/60125/index.html` | Transcript, language check | Đạt |
| 2 | `60126` | `/tasks/60126` | `/tasks/60126/index.html` | Priority review, mastery | Đạt |
| 3 | `60131` | `/tasks/60131` | `/tasks/60131/index.html` | Input, retry, transfer | Đạt |
| 3 | `60132` | `/tasks/60132` | `/tasks/60132/index.html` | Form/meaning choices | Đạt |
| 3 | `60133` | `/tasks/60133` | `/tasks/60133/index.html` | Frequency position | Đạt |
| 3 | `60134` | `/tasks/60134` | `/tasks/60134/index.html` | Frequency meaning | Đạt |
| 3 | `60135` | `/tasks/60135` | `/tasks/60135/index.html` | STT simulation, grammar check | Đạt |
| 4 | `60141` | `/tasks/60141` | `/tasks/60141/index.html` | Functional phrases | Đạt |
| 4 | `60142` | `/tasks/60142` | `/tasks/60142/index.html` | Meaning/appropriacy | Đạt |
| 4 | `60143` | `/tasks/60143` | `/tasks/60143/index.html` | Supported dialogue, transcript | Đạt |
| 4 | `60144` | `/tasks/60144` | `/tasks/60144/index.html` | Role-play, mastery | Đạt |
| 5 | `60151` | `/tasks/60151` | `/tasks/60151/index.html` | Main idea, Guided/Independent | Đạt |
| 5 | `60152` | `/tasks/60152` | `/tasks/60152/index.html` | Reading details, Guided retry | Đạt |
| 5 | `60153` | `/tasks/60153` | `/tasks/60153/index.html` | Conversation cohesion | Đạt |
| 5 | `60154` | `/tasks/60154` | `/tasks/60154/index.html` | Speaking readiness | Đạt |
| 5 | `60155` | `/tasks/60155` | `/tasks/60155/index.html` | Multi-round speaking, mastery | Đạt |

Tổng: **26/26 task đạt**.
