import { readFileSync, readdirSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

function filesUnder(directory: string): string[] {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name)
    return entry.isDirectory() ? filesUnder(path) : [path]
  })
}

describe('locked React architecture contract', () => {
  it('keeps task content free of imperative HTML and global DOM control', () => {
    const files = filesUnder(resolve('src/tasks')).filter((file) => /\.(ts|tsx)$/.test(file))
    const source = files.map((file) => readFileSync(file, 'utf8')).join('\n')
    expect(source).not.toMatch(/dangerouslySetInnerHTML|\.innerHTML|insertAdjacentHTML|document\.write|document\.querySelector/)
  })

  it('keeps Foundation avatar, row and bubble selectors out of task CSS', () => {
    const files = filesUnder(resolve('src/tasks')).filter((file) => file.endsWith('.css'))
    for (const file of files) {
      const css = readFileSync(file, 'utf8')
      expect(css, file).not.toMatch(/\.task-\d+\s+\.(ui-avatar|chat-row|chat-bubble(?:--tutor|--student)?)(?![\w-])/)
    }
  })

  it('routes migrated tasks through the shared interactive frame', () => {
    for (const code of ['60131', '60154', '60155']) {
      const source = readFileSync(resolve(`src/tasks/${code}/Task${code}.tsx`), 'utf8')
      expect(source).toContain('<InteractiveTaskFrame')
      expect(source).not.toContain('<CodeKeypadModal')
      expect(source).not.toContain('<TutorHeader')
    }
  })
})
