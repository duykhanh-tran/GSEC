import { useReducer, useState, type CSSProperties } from 'react'

import type { TaskComponentProps } from '../../app/task-types'
import { ChatRow } from '../../components/chat/ChatRow'
import { TutorBubble } from '../../components/chat/TutorBubble'
import { InteractiveTaskFrame } from '../../components/shell/InteractiveTaskFrame'
import { StatusFooter } from '../../components/shell/StatusFooter'
import { ActionButton } from '../../components/task/ActionButton'
import { StatusTag } from '../../components/task/StatusTag'
import { TaskPanel } from '../../components/task/TaskPanel'
import { useAutoScroll } from '../../hooks/useAutoScroll'
import { useTaskTimers } from '../../hooks/useTaskTimers'
import { DEMO_ANSWERS, GRAMMAR_ITEMS, ITEM_IDS, TRANSFER_ITEMS, itemIsCorrect, normalizeAnswer, type GrammarTag } from './data'
import { initialState60131, reducer60131, type TutorNotice } from './reducer'
import './task.css'

export function Task60131({ task }: TaskComponentProps) {
  const [state, dispatch] = useReducer(reducer60131, initialState60131)
  const [showConfetti, setShowConfetti] = useState(false)
  const schedule = useTaskTimers()
  const activeQuestion = state.wrongQueue[0]
  const activeTransfer = state.transferQueue[0]
  const { chatRef } = useAutoScroll(`${state.notices.length}-${state.retryAttempt}-${state.retryFeedback}-${state.transferFeedback}-${state.complete}`)

  const startRetry = (id: number) => {
    dispatch({ type: 'notice', notice: { kind: 'question', question: id } })
    dispatch({ type: 'start-retry', values: GRAMMAR_ITEMS[id].key.map(() => '') })
  }

  const startTransfers = () => {
    dispatch({ type: 'notice', notice: { kind: 'transfer-intro' } })
    dispatch({ type: 'start-transfer' })
  }

  const finish = () => {
    dispatch({ type: 'finish' })
    setShowConfetti(true)
    schedule(() => setShowConfetti(false), 3500)
  }

  const advanceRetry = (id: number, values: string[]) => {
    const nextQuestion = state.wrongQueue[1]
    dispatch({ type: 'resolve-retry', id, values })
    if (nextQuestion) schedule(() => startRetry(nextQuestion), 0)
    else schedule(() => state.weakTags.length ? startTransfers() : finish(), 0)
  }

  const checkAll = () => {
    if (ITEM_IDS.some((id) => state.answers[id].some((value) => !value.trim()))) {
      dispatch({ type: 'notice', notice: { kind: 'complete-first' } })
      return
    }
    const wrong = ITEM_IDS.filter((id) => !itemIsCorrect(state.answers, id))
    const tags = [...new Set(wrong.map((id) => GRAMMAR_ITEMS[id].tag))]
    dispatch({ type: 'checked', wrong, tags })
    if (!wrong.length) { finish(); return }
    dispatch({ type: 'notice', notice: { kind: 'wrong-list', ids: wrong } })
    schedule(() => startRetry(wrong[0]), 220)
  }

  const checkRetry = () => {
    const item = GRAMMAR_ITEMS[activeQuestion]
    const correct = item.key.every((value, part) => normalizeAnswer(state.retryValues[part]) === normalizeAnswer(value))
    if (correct) {
      dispatch({ type: 'retry-feedback', value: 'Correct ✓' })
      schedule(() => advanceRetry(activeQuestion, state.retryValues), 600)
    } else if (state.retryAttempt === 1) {
      dispatch({ type: 'retry-feedback', value: 'Not yet.' })
      schedule(() => dispatch({ type: 'retry-second', values: item.key.map(() => '') }), 600)
    } else {
      dispatch({ type: 'retry-feedback', value: `Correct form: ${item.key.join(' … ')}.` })
      schedule(() => advanceRetry(activeQuestion, [...item.key]), 1000)
    }
  }

  const chooseTransfer = (value: string) => {
    const transfer = TRANSFER_ITEMS[activeTransfer]
    if (value === transfer.key) {
      dispatch({ type: 'transfer-feedback', value: 'Got it ✓' })
      schedule(() => {
        if (state.transferQueue.length === 1) finish()
        else dispatch({ type: 'resolve-transfer' })
      }, 600)
    } else {
      dispatch({ type: 'transfer-feedback', value: 'Not yet. Use the same rule you just reviewed.', wrong: value })
      schedule(() => dispatch({ type: 'transfer-feedback', value: '' }), 700)
    }
  }

  return (
    <InteractiveTaskFrame
      task={task}
      className="task-60131"
      chatRef={chatRef}
      footer={<StatusFooter title={state.complete ? 'Task 1 complete' : 'Task 1'} status={state.complete ? 'Continue to Task 2.' : 'Check 8 answers.'} actionLabel="Back to book" actionId="backBook" disabled={!state.complete} onAction={() => dispatch({ type: 'notice', notice: { kind: 'back' } })} />}
    >
      <ChatRow role="tutor"><TutorBubble><strong>Check Task 1.</strong><br />Use your worksheet. Enter only the words you wrote in the blanks.</TutorBubble></ChatRow>

      {state.entryVisible ? <EntryCard state={state} dispatch={dispatch} onCheck={checkAll} /> : null}
      {state.resultWrong ? <ResultsCard wrong={state.resultWrong} /> : null}
      {state.notices.map((notice) => <Notice notice={notice} key={notice.id} />)}
      {!state.complete && activeQuestion && state.retryValues.length ? <RetryCard state={state} question={activeQuestion} dispatch={dispatch} onCheck={checkRetry} /> : null}
      {!state.complete && !activeQuestion && activeTransfer ? <TransferCard tag={activeTransfer} feedback={state.transferFeedback} wrong={state.transferWrong} onChoose={chooseTransfer} /> : null}
      {state.complete ? <CompleteSummary /> : null}
      {showConfetti ? <Confetti /> : null}
    </InteractiveTaskFrame>
  )
}

function EntryCard({ state, dispatch, onCheck }: { state: typeof initialState60131; dispatch: React.Dispatch<Parameters<typeof reducer60131>[1]>; onCheck: () => void }) {
  return <TaskPanel title="Your answers" subtitle="8 items" data-stage="entry"><div className="answer-list" data-answer-list>{ITEM_IDS.map((id) => <div className="answer-row" key={id}><div className="num">{id}</div><div className={GRAMMAR_ITEMS[id].key.length > 1 ? 'double' : ''}>{GRAMMAR_ITEMS[id].key.map((_, part) => <input className="entry" type="text" autoComplete="off" data-answer-index={id} data-answer-part={part} placeholder={GRAMMAR_ITEMS[id].key.length === 1 ? 'Your answer' : part === 0 ? 'Auxiliary' : 'Verb'} value={state.answers[id][part]} onChange={(event) => dispatch({ type: 'answer', id, part, value: event.target.value })} key={part} />)}</div></div>)}</div><div className="actions"><ActionButton variant="secondary" className="btn secondary" data-demo onClick={() => dispatch({ type: 'demo', answers: DEMO_ANSWERS })}>Demo</ActionButton><ActionButton className="btn primary" data-check onClick={onCheck}>Check</ActionButton></div><div className="note">Enter only the verb form(s), not the full sentence.</div></TaskPanel>
}

function ResultsCard({ wrong }: { wrong: number[] }) {
  return <TaskPanel title="Task 1 check" subtitle={`${8 - wrong.length}/8 correct`} data-stage="results">{ITEM_IDS.map((id) => <div className="result" key={id}><span>Question {id}</span><StatusTag tone={wrong.includes(id) ? 'error' : 'success'}>{wrong.includes(id) ? 'Try again' : 'Correct ✓'}</StatusTag></div>)}</TaskPanel>
}

function Notice({ notice }: { notice: TutorNotice }) {
  let content
  if (notice.kind === 'complete-first') content = <>Complete all 8 answers first.</>
  else if (notice.kind === 'wrong-list') content = <>Questions <strong>{notice.ids.join(', ')}</strong> need a quick fix.</>
  else if (notice.kind === 'question') content = <><strong>Question {notice.question}</strong><br />{GRAMMAR_ITEMS[notice.question].h1}</>
  else if (notice.kind === 'transfer-intro') content = <>Now one quick new item for each grammar point that needed extra help.</>
  else if (notice.kind === 'done') content = <><strong>All correct ✓</strong><br />Great work. Back to your book for Task 2.</>
  else content = <>Keep going. I’ll be here when you need me.</>
  return <ChatRow role="tutor"><TutorBubble>{content}</TutorBubble></ChatRow>
}

function RetryCard({ state, question, dispatch, onCheck }: { state: typeof initialState60131; question: number; dispatch: React.Dispatch<Parameters<typeof reducer60131>[1]>; onCheck: () => void }) {
  const item = GRAMMAR_ITEMS[question]
  return <section className="retry" data-stage="retry" data-question={question} data-attempt={state.retryAttempt}><div className="retry-head"><strong>Question {question}</strong><StatusTag tone="warning">{item.tag}</StatusTag></div><div className="sentence">{item.prompt}</div><div className="hint">{state.retryAttempt === 1 ? item.h1 : item.h2}</div>{state.retryAttempt > 1 ? <div className="rule">{item.rule}</div> : null}<div className={`retry-fields ${item.key.length > 1 ? 'double' : ''}`}>{item.key.map((_, part) => <input autoFocus={part === 0} className="retry-input" type="text" autoComplete="off" data-retry-part={part} placeholder={item.key.length === 1 ? 'Try again' : part === 0 ? 'Auxiliary' : 'Base verb'} value={state.retryValues[part] ?? ''} onChange={(event) => dispatch({ type: 'retry-value', part, value: event.target.value })} key={part} />)}</div><ActionButton className="btn primary retry-check" data-retry-check onClick={onCheck}>Check again</ActionButton><div className={`micro ${state.retryFeedback === 'Correct ✓' ? 'ok' : state.retryFeedback ? 'bad' : ''}`}>{state.retryFeedback}</div></section>
}

function TransferCard({ tag, feedback, wrong, onChoose }: { tag: GrammarTag; feedback: string; wrong: string; onChoose: (value: string) => void }) {
  const item = TRANSFER_ITEMS[tag]
  return <section className="transfer" data-stage="transfer" data-tag={tag}><div className="retry-head"><strong>Quick check</strong><StatusTag tone="warning">New item</StatusTag></div><div className="sentence">{item.text}</div><div className="options">{item.options.map((value) => <button type="button" className={`opt ${feedback === 'Got it ✓' && value === item.key ? 'sel' : wrong === value ? 'wrong' : ''}`.trim()} data-option={value} disabled={feedback === 'Got it ✓'} onClick={() => onChoose(value)} key={value}>{value}</button>)}</div><div className={`micro ${feedback === 'Got it ✓' ? 'ok' : feedback ? 'bad' : ''}`}>{feedback}</div></section>
}

function CompleteSummary() {
  return <TaskPanel title="Task 1 complete ✓" subtitle="Present Simple" variant="summary" data-stage="complete">{ITEM_IDS.map((id) => <div className="result" key={id}><span>Question {id}</span><StatusTag tone="success">Correct ✓</StatusTag></div>)}<div className="note">First-attempt errors and retry history are stored separately, even though every answer is correct at the end.</div></TaskPanel>
}

function Confetti() {
  const colors = ['#8B0450', '#B85A89', '#E8A6C3', '#16a34a', '#f59e0b']
  return <>{Array.from({ length: 40 }, (_, index) => <span className="confetti" style={{ left: `${(index * 37) % 100}vw`, background: colors[index % colors.length], animationDuration: `${1.8 + (index % 8) * 0.17}s`, '--drift': `${(index * 29) % 180 - 90}px` } as CSSProperties} key={index} />)}</>
}
