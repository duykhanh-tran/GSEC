import type { ReactNode } from 'react'

interface AppShellProps {
  header: ReactNode
  footer?: ReactNode
  children: ReactNode
}

export function AppShell({ header, footer, children }: AppShellProps) {
  return (
    <section className="task task-foundation" data-react-foundation="foundation-1">
      <div className="app">
        {header}
        <main className="chat" id="chat">
          {children}
        </main>
        {footer}
      </div>
    </section>
  )
}
