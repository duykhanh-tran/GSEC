import { describe, expect, it } from 'vitest'

import {
  DEFAULT_TASK_CODE,
  TASK_CODES,
  TASKS,
  getTask,
  getTaskPath,
  hasTask,
  normalizeTaskCode,
} from '../../src/app/registry'

describe('task registry', () => {
  it('contains exactly 26 unique five-digit task codes', () => {
    expect(TASKS).toHaveLength(26)
    expect(TASK_CODES).toHaveLength(26)
    expect(new Set(TASK_CODES).size).toBe(26)
    expect(TASK_CODES.every((code) => /^\d{5}$/.test(code))).toBe(true)
  })

  it('keeps the complete metadata and routing contract', () => {
    expect(DEFAULT_TASK_CODE).toBe('60111')
    expect(getTask(' 60154 ')).toMatchObject({
      code: '60154',
      worksheet: 5,
      taskNumber: 4,
      title: 'AI Tutor • WS 5 - Task 4',
      legacyUrl: '/tasks/60154/index.html',
    })
    expect(getTaskPath('60154')).toBe('/tasks/60154')
    expect(hasTask('99999')).toBe(false)
    expect(normalizeTaskCode(null)).toBe('')
  })

  it('maps every Stage 6 task to a real React implementation', () => {
    expect(TASKS.every((task) => task.component.name !== 'FoundationTaskPage')).toBe(true)
  })
})
