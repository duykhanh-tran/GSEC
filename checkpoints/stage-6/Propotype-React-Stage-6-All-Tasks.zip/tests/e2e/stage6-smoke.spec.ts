import { expect, test } from '@playwright/test'
const TASK_CODES = ['60111','60112','60113','60114','60115','60116','60121','60122','60123','60124','60125','60126','60131','60132','60133','60134','60135','60141','60142','60143','60144','60151','60152','60153','60154','60155']

test.beforeEach(async ({ page }) => { await page.route('https://dl.dropboxusercontent.com/**', (route) => route.fulfill({ status: 200, contentType: 'image/gif', body: Buffer.from('R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==', 'base64') })) })

test('all 26 routes render a registered React task without placeholder content', async ({ page }) => {
  test.setTimeout(90_000)
  for (const code of TASK_CODES) {
    await page.goto(`/tasks/${code}`)
    const root = page.locator(`[data-task='${code}'][data-module-ready='true']`)
    await expect(root).toBeVisible()
    await expect(root).not.toContainText('will be replaced during the task migration stages')
  }
})

test('all 26 task shells avoid horizontal overflow at desktop and mobile widths', async ({ page }) => {
  test.setTimeout(120_000)
  for (const code of TASK_CODES) {
    await page.setViewportSize({ width: 1024, height: 900 })
    await page.goto(`/tasks/${code}`)
    await expect(page.locator(`[data-task='${code}']`)).toBeVisible()
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)).toBe(true)
    await page.setViewportSize({ width: 390, height: 844 })
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth)).toBe(true)
  }
})
