import type { ReactNode } from 'react'

export type TaskArchetype =
  | 'answer-entry'
  | 'choice-assessment'
  | 'retry-coaching'
  | 'listening'
  | 'speech-recording'
  | 'transcript-repair'
  | 'writing-repair'
  | 'readiness-checklist'
  | 'mastery-review'
  | 'role-play'
  | 'reading-comprehension'

export interface TaskAuthoringSchema {
  code: string
  archetypes: readonly TaskArchetype[]
  version: 1
}

export type TaskFlowBlock =
  | {
      id: string
      type: 'tutor-message'
      content: ReactNode
      speechText?: string
    }
  | {
      id: string
      type: 'panel'
      title: string
      subtitle: ReactNode
      stage?: string
      variant?: 'card' | 'summary'
      content: ReactNode
    }
  | {
      id: string
      type: 'custom'
      content: ReactNode
    }
  | {
      id: string
      type: 'celebration'
      active: boolean
      durationMs?: number
      onComplete?: () => void
    }

export interface ChoiceOptionConfig {
  value: string
  label: ReactNode
  disabled?: boolean
}

export interface AnswerMatrixRowConfig {
  id: string | number
  prompt: ReactNode
  options: readonly ChoiceOptionConfig[]
}

export interface RetryFieldConfig {
  id: string | number
  placeholder: string
  value: string
}

export interface ScoreItemConfig {
  id: string
  label: string
  value: string
  tone?: 'default' | 'success' | 'warning' | 'error'
}

export interface ProgressStepConfig {
  id: string
  label: string
  status: 'pending' | 'active' | 'complete'
}
