import type { GuidedChoiceTaskConfig } from '../../components/assessment/GuidedChoiceTask'

export const TASK_60141_CONFIG = {
  className: 'task-60141',
  intro: <><strong>Check Task 1.</strong><br />Enter the phrases you used for blanks 1–4 in the worksheet.</>,
  entryTitle: 'Your worksheet answers', entrySubtitle: '4 blanks',
  entryNote: 'The worksheet remains the main task. The app only records which functional phrase you used in each blank.',
  options: ['this is', 'Hello', 'Nice to meet you', 'Nice to meet you, too'],
  items: [
    { id: 1, key: 'this is', firstHint: 'You are introducing Ben to Mai. Which phrase goes before Ben’s name?', secondHint: 'Choose the phrase used to introduce another person.', retryTag: 'FUNCTION', bookCue: 'Read the dialogue line again.', retryContent: <div className="dialogue">Linh: Mai, <strong>(1)</strong> Ben, my new classmate.</div>, summaryLabel: 'Blank 1', summaryValue: 'this is ✓' },
    { id: 2, key: 'Hello', firstHint: 'Mai speaks to Ben for the first time. Start with a short greeting.', secondHint: 'Choose the simple greeting phrase.', retryTag: 'FUNCTION', bookCue: 'Read the dialogue line again.', retryContent: <div className="dialogue">Mai: <strong>(2)</strong>, Ben.</div>, summaryLabel: 'Blank 2', summaryValue: 'Hello ✓' },
    { id: 3, key: 'Nice to meet you', firstHint: 'Mai is meeting Ben for the first time. Which polite phrase fits here?', secondHint: 'Choose the phrase used when meeting someone for the first time.', retryTag: 'FUNCTION', bookCue: 'Read the dialogue line again.', retryContent: <div className="dialogue">Mai: Hello, Ben. <strong>(3)</strong>.</div>, summaryLabel: 'Blank 3', summaryValue: 'Nice to meet you ✓' },
    { id: 4, key: 'Nice to meet you, too', firstHint: 'Ben is responding after Mai says “Nice to meet you.”', secondHint: 'Choose the matching response phrase.', retryTag: 'FUNCTION', bookCue: 'Read the dialogue line again.', retryContent: <div className="dialogue">Ben: Hi, Mai. <strong>(4)</strong>.</div>, summaryLabel: 'Blank 4', summaryValue: 'Nice to meet you, too ✓' },
  ],
  demoAnswers: { 1: 'this is', 2: 'Nice to meet you', 3: 'Hello', 4: 'Nice to meet you, too' },
  incompleteMessage: 'Choose one phrase for all 4 blanks first.', itemSingular: 'Blank', itemPlural: 'Blanks', retryDataAttribute: 'blank',
  resultsTitle: 'Task 1 check', summaryTitle: 'Task 1 complete ✓', summarySubtitle: 'Everyday English', evidenceTag: 'FUNCTION',
  evidenceNote: 'First-attempt errors can be stored as functional-language evidence for later review.', footerIdle: 'Check 4 answers.', footerComplete: 'Continue to Task 2.', continueLabel: 'Task 2',
  completeIndependent: 'All correct. Back to your book for Task 2.', completeGuided: 'All correct. Back to your book for Task 2.', backMessage: 'Keep going. I’ll be here when you need me.',
  maxAttempts: 2, guidedAtLimit: false, summaryMode: 'answers', wrongSuffix: '',
} satisfies GuidedChoiceTaskConfig
