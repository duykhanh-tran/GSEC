# AI Tutor GSEC 6 — React

Đây là dự án React độc lập dùng để chuyển đổi hệ thống HTML trong thư mục
`../Propotype`. Thư mục HTML gốc chỉ được dùng làm baseline và không được liên
kết runtime hoặc chỉnh sửa trong quá trình chuyển đổi.

## Công nghệ nền tảng

- React và TypeScript strict
- Vite
- React Router
- Vitest và React Testing Library
- Playwright

## Lệnh phát triển

```bash
npm install
npm run dev -- --port 4174
npm run test
npm run build
npm run preview -- --port 4175
npm run test:e2e:static
npm run test:e2e:parity
```

Foundation React đã hoàn thành ở Giai đoạn 3. Ba pilot `60131`, `60154`, `60155`
được dùng để khóa kiến trúc; hiện đủ 26 task React và đã hoàn thành URL compatibility
cùng static hosting ở Giai đoạn 7.

- Contract hiện hành: `REACT-ARCHITECTURE-STANDARD.md` (`architecture-2`).
- Phân loại task: `TASK-ARCHETYPE-CATALOG.md`.
- Schema authoring: `TASK-AUTHORING-SCHEMA.md`.
- Báo cáo Giai đoạn 6: `STAGE-6-REPORT.md`.
- Báo cáo Giai đoạn 7: `STAGE-7-REPORT.md`.
- Báo cáo Giai đoạn 8: `STAGE-8-REPORT.md`.

Lệnh `npm run build` tự sinh 26 entry point tĩnh trong `dist/tasks/` và
`dist/404.html`. Lệnh `npm run test:e2e:static` kiểm tra các URL này bằng máy
chủ tĩnh không có SPA fallback.

Lệnh `npm run test:e2e:parity` khởi động đồng thời baseline HTML và React build,
đối chiếu đủ 26 task ở mobile/desktop và lưu bằng chứng trong
`reports/stage-8-visual/`.
