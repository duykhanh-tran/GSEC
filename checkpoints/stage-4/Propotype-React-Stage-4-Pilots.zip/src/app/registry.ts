import { FoundationTaskPage } from './pages/FoundationTaskPage'
import type { TaskDefinition, WorksheetNumber } from './task-types'
import { Task60154 } from '../tasks/60154/Task60154'
import { Task60131 } from '../tasks/60131/Task60131'
import { Task60155 } from '../tasks/60155/Task60155'

const taskRows = [
  ['60111', 1, 1, 'AI Tutor • WS 1 - Task 1', 'Unit 1 · My New School'],
  ['60112', 1, 2, 'AI Tutor • WS 1 - Task 2', 'Unit 1 · My New School'],
  ['60113', 1, 3, 'AI Tutor • WS 1 - Task 3', 'Unit 1 · My New School'],
  ['60114', 1, 4, 'AI Tutor • WS 1 - Task 4', 'Unit 1 · My New School'],
  ['60115', 1, 5, 'AI Tutor • WS 1 - Task 5', 'Unit 1 · My New School'],
  ['60116', 1, 6, 'AI Tutor • WS 1 - Task 6', 'Unit 1 · My New School'],
  ['60121', 2, 1, 'AI Tutor • WS 2 - Task 1', 'Unit 1 · My New School'],
  ['60122', 2, 2, 'AI Tutor • WS 2 - Task 2', 'Unit 1 · My New School'],
  ['60123', 2, 3, 'AI Tutor • WS 2 - Task 3', 'Listening & Pronunciation'],
  ['60124', 2, 4, 'AI Tutor • WS 2 - Task 4', 'Sentence Fluency'],
  ['60125', 2, 5, 'AI Tutor • WS 2 - Task 5', 'Collocation & Language Check'],
  ['60126', 2, 6, 'AI Tutor • WS 2 - Task 6', 'Priority Review · Mastery Check'],
  ['60131', 3, 1, 'AI Tutor • WS 3 - Task 1', 'Present Simple · Form First'],
  ['60132', 3, 2, 'AI Tutor • WS 3 - Task 2', 'Form & Meaning in Context'],
  ['60133', 3, 3, 'AI Tutor • WS 3 - Task 3', 'Frequency Words · Position'],
  ['60134', 3, 4, 'AI Tutor • WS 3 - Task 4', 'Frequency Meaning · School Week'],
  ['60135', 3, 5, 'AI Tutor • WS 3 - Task 5', 'Personal Writing · STT Grammar Check'],
  ['60141', 4, 1, 'AI Tutor • WS 4 - Task 1', 'Everyday English · Functional Phrases'],
  ['60142', 4, 2, 'AI Tutor • WS 4 - Task 2', 'Meaning & Appropriacy'],
  ['60143', 4, 3, 'AI Tutor • WS 4 - Task 3', 'Supported Dialogue · STT Check'],
  ['60144', 4, 4, 'AI Tutor • WS 4 - Task 4', 'AI Role-play · Communication'],
  ['60151', 5, 1, 'AI Tutor • WS 5 - Task 1', 'Read for the Big Idea'],
  ['60152', 5, 2, 'AI Tutor • WS 5 - Task 2', 'Reading Comprehension · Details & Meaning'],
  ['60153', 5, 3, 'AI Tutor • WS 5 - Task 3', 'Conversation · Discourse Cohesion'],
  ['60154', 5, 4, 'AI Tutor • WS 5 - Task 4', 'Speaking Plan · Readiness Check'],
  ['60155', 5, 5, 'AI Tutor • WS 5 - Task 5', 'AI Speaking · My School Choice'],
] as const

export type TaskCode = (typeof taskRows)[number][0]

const taskComponents: Partial<Record<TaskCode, TaskDefinition['component']>> = {
  '60131': Task60131,
  '60154': Task60154,
  '60155': Task60155,
}

export const TASKS: readonly TaskDefinition[] = Object.freeze(
  taskRows.map(([code, worksheet, taskNumber, title, subtitle]) =>
    Object.freeze({
      code,
      worksheet: worksheet as WorksheetNumber,
      taskNumber,
      title,
      subtitle,
      component: taskComponents[code] ?? FoundationTaskPage,
      legacyUrl: `/tasks/${code}/index.html`,
    }),
  ),
)

export const TASK_CODES: readonly TaskCode[] = Object.freeze(
  taskRows.map(([code]) => code),
)

export const DEFAULT_TASK_CODE: TaskCode = TASK_CODES[0]

const taskMap = new Map(TASKS.map((task) => [task.code, task]))

export function normalizeTaskCode(value: unknown): string {
  return String(value ?? '').trim()
}

export function getTask(value: unknown): TaskDefinition | null {
  return taskMap.get(normalizeTaskCode(value)) ?? null
}

export function hasTask(value: unknown): boolean {
  return getTask(value) !== null
}

export function getTaskPath(value: unknown): string | null {
  const task = getTask(value)
  return task ? `/tasks/${task.code}` : null
}
