import type { ComponentType } from 'react'

export type WorksheetNumber = 1 | 2 | 3 | 4 | 5

export interface TaskComponentProps {
  task: TaskDefinition
}

export interface TaskDefinition {
  code: string
  worksheet: WorksheetNumber
  taskNumber: number
  title: string
  subtitle: string
  component: ComponentType<TaskComponentProps>
  legacyUrl: string
}
