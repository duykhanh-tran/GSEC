import { useCallback, useEffect, useRef, useState } from 'react'

type RecordingStatus = 'idle' | 'recording' | 'converting' | 'done'

export function useRecordingSimulation(onDone: () => void) {
  const [status, setStatus] = useState<RecordingStatus>('idle')
  const [elapsed, setElapsed] = useState(0)
  const intervalRef = useRef<number | null>(null)
  const timeoutsRef = useRef<Set<number>>(new Set())
  const onDoneRef = useRef(onDone)

  useEffect(() => {
    onDoneRef.current = onDone
  }, [onDone])

  const cleanup = useCallback(() => {
    if (intervalRef.current !== null) window.clearInterval(intervalRef.current)
    intervalRef.current = null
    timeoutsRef.current.forEach(window.clearTimeout)
    timeoutsRef.current.clear()
  }, [])

  const start = useCallback(() => {
    cleanup()
    setElapsed(0)
    setStatus('recording')
    intervalRef.current = window.setInterval(() => setElapsed((value) => value + 0.1), 100)
    const stopTimer = window.setTimeout(() => {
      if (intervalRef.current !== null) window.clearInterval(intervalRef.current)
      intervalRef.current = null
      setStatus('converting')
      const convertTimer = window.setTimeout(() => {
        timeoutsRef.current.delete(convertTimer)
        setStatus('done')
        onDoneRef.current()
      }, 500)
      timeoutsRef.current.add(convertTimer)
    }, 1200)
    timeoutsRef.current.add(stopTimer)
  }, [cleanup])

  const reset = useCallback(() => {
    cleanup()
    setElapsed(0)
    setStatus('idle')
  }, [cleanup])

  useEffect(() => cleanup, [cleanup])
  return { status, elapsed, start, reset }
}
