import { useCallback, useEffect } from 'react'

export function useSpeechSynthesis() {
  const speak = useCallback((text: string) => {
    if (!('speechSynthesis' in window)) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'en-US'
    utterance.rate = 0.92
    window.speechSynthesis.speak(utterance)
  }, [])

  useEffect(() => () => window.speechSynthesis?.cancel(), [])
  return speak
}
