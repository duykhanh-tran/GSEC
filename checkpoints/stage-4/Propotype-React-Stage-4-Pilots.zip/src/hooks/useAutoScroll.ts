import { useCallback, useEffect, useRef, type RefObject } from 'react'

export function useAutoScroll(changeKey: unknown): {
  chatRef: RefObject<HTMLElement | null>
  scrollToLatest: (element?: Element | null) => void
} {
  const chatRef = useRef<HTMLElement>(null)

  const scrollToLatest = useCallback((element?: Element | null) => {
    const target = element ?? chatRef.current?.lastElementChild
    window.setTimeout(() => target?.scrollIntoView({ behavior: 'smooth', block: 'end' }), 60)
  }, [])

  useEffect(() => {
    scrollToLatest()
  }, [changeKey, scrollToLatest])

  return { chatRef, scrollToLatest }
}
