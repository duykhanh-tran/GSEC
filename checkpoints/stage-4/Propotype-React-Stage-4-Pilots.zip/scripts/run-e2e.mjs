import { spawn } from 'node:child_process'
import { setTimeout as delay } from 'node:timers/promises'

const baseUrl = 'http://127.0.0.1:4174'
const viteCli = './node_modules/vite/bin/vite.js'
const playwrightCli = './node_modules/@playwright/test/cli.js'

async function isReachable() {
  try {
    const response = await fetch(baseUrl)
    return response.ok
  } catch {
    return false
  }
}

async function waitForServer(server, timeoutMs = 30_000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    if (server.exitCode !== null) {
      throw new Error(`Vite dev server exited with code ${server.exitCode}.`)
    }
    if (await isReachable()) return
    await delay(150)
  }
  throw new Error(`Vite dev server did not become ready at ${baseUrl}.`)
}

async function stopServer(server) {
  if (server.exitCode !== null) return
  server.kill('SIGTERM')
  await Promise.race([
    new Promise((resolve) => server.once('exit', resolve)),
    delay(3_000),
  ])
  if (server.exitCode === null) server.kill('SIGKILL')
}

if (await isReachable()) {
  throw new Error(`Port 4174 is already in use. Stop the existing server and retry.`)
}

const server = spawn(
  process.execPath,
  [viteCli, '--host', '127.0.0.1', '--port', '4174', '--strictPort'],
  { stdio: ['ignore', 'pipe', 'pipe'] },
)

server.stdout.on('data', (chunk) => process.stdout.write(`[vite] ${chunk}`))
server.stderr.on('data', (chunk) => process.stderr.write(`[vite] ${chunk}`))

let exitCode = 1
try {
  await waitForServer(server)
  const tests = spawn(process.execPath, [playwrightCli, 'test'], {
    stdio: 'inherit',
  })
  exitCode = await new Promise((resolve) => tests.once('exit', resolve))
} finally {
  await stopServer(server)
  server.stdout.destroy()
  server.stderr.destroy()
}

process.exit(exitCode ?? 1)
