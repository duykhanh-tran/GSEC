# AI Tutor GSEC 6 — React

Đây là dự án React độc lập dùng để chuyển đổi hệ thống HTML trong thư mục
`../Propotype`. Thư mục HTML gốc chỉ được dùng làm baseline và không được liên
kết runtime hoặc chỉnh sửa trong quá trình chuyển đổi.

## Công nghệ nền tảng

- React và TypeScript strict
- Vite
- React Router
- Vitest và React Testing Library
- Playwright

## Lệnh phát triển

```bash
npm install
npm run dev -- --port 4174
npm run test
npm run build
npm run preview -- --port 4175
```

Foundation React đã hoàn thành ở Giai đoạn 3. Quy tắc component, token, registry
và keypad nằm trong `FOUNDATION-STANDARD.md`; kết quả nghiệm thu nằm trong
`STAGE-3-REPORT.md`.

Các trang task hiện chỉ dùng placeholder Foundation. Logic học tập được chuyển
từng task từ Giai đoạn 4 theo `../REACT-MIGRATION-SPEC.md`.
