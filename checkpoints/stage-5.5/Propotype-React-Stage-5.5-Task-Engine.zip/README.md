# AI Tutor GSEC 6 — React

Đây là dự án React độc lập dùng để chuyển đổi hệ thống HTML trong thư mục
`../Propotype`. Thư mục HTML gốc chỉ được dùng làm baseline và không được liên
kết runtime hoặc chỉnh sửa trong quá trình chuyển đổi.

## Công nghệ nền tảng

- React và TypeScript strict
- Vite
- React Router
- Vitest và React Testing Library
- Playwright

## Lệnh phát triển

```bash
npm install
npm run dev -- --port 4174
npm run test
npm run build
npm run preview -- --port 4175
```

Foundation React đã hoàn thành ở Giai đoạn 3. Ba pilot `60131`, `60154`, `60155`
đã được chuyển và Giai đoạn 5.5 đã bổ sung task engine hướng cấu hình.

- Contract hiện hành: `REACT-ARCHITECTURE-STANDARD.md` (`architecture-2`).
- Phân loại task: `TASK-ARCHETYPE-CATALOG.md`.
- Schema authoring: `TASK-AUTHORING-SCHEMA.md`.
- Báo cáo Giai đoạn 5.5: `STAGE-5.5-REPORT.md`.

23 task còn lại vẫn là placeholder Foundation và chỉ được chuyển trong Giai
đoạn 6 theo `../REACT-MIGRATION-SPEC.md`.
