import type { AnswerMatrixRowConfig } from '../../task-engine/schema'
import { ChoiceGroup } from './ChoiceGroup'

interface AnswerChoiceMatrixProps {
  rows: readonly AnswerMatrixRowConfig[]
  values: Readonly<Record<string, string | undefined>>
  disabled?: boolean
  onChange: (rowId: string, value: string) => void
}

export function AnswerChoiceMatrix({ rows, values, disabled = false, onChange }: AnswerChoiceMatrixProps) {
  return (
    <div className="answer-choice-matrix matrix" data-answer-matrix>
      {rows.map((row) => {
        const id = String(row.id)
        return (
          <div className="answer-choice-matrix__row" data-question={id} key={id}>
            <div className="answer-choice-matrix__prompt">{row.prompt}</div>
            <ChoiceGroup
              ariaLabel={`Question ${id}`}
              options={row.options}
              value={values[id]}
              disabled={disabled}
              onChange={(value) => onChange(id, value)}
            />
          </div>
        )
      })}
    </div>
  )
}
