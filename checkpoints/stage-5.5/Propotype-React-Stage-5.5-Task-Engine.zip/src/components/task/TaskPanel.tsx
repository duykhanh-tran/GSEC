import type { HTMLAttributes, ReactNode } from 'react'

interface TaskPanelProps extends HTMLAttributes<HTMLElement> {
  title: string
  subtitle: string
  variant?: 'card' | 'summary'
  children: ReactNode
}

export function TaskPanel({
  title,
  subtitle,
  variant = 'card',
  className = '',
  children,
  ...props
}: TaskPanelProps) {
  const baseClass = variant === 'summary' ? 'summary' : 'card'
  return (
    <section className={`${baseClass} ${className}`.trim()} {...props}>
      <div className="ch">
        <h2>{title}</h2>
        <span>{subtitle}</span>
      </div>
      <div className="cb">{children}</div>
    </section>
  )
}
