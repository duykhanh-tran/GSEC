import type { ProgressStepConfig } from '../../task-engine/schema'

interface ProgressStepsProps {
  steps: readonly ProgressStepConfig[]
  ariaLabel?: string
}

export function ProgressSteps({ steps, ariaLabel = 'Task progress' }: ProgressStepsProps) {
  return (
    <ol className="progress-steps" aria-label={ariaLabel}>
      {steps.map((step) => (
        <li className={`progress-step progress-step--${step.status}`} aria-current={step.status === 'active' ? 'step' : undefined} key={step.id}>
          <span aria-hidden="true">{step.status === 'complete' ? '✓' : ''}</span>{step.label}
        </li>
      ))}
    </ol>
  )
}
