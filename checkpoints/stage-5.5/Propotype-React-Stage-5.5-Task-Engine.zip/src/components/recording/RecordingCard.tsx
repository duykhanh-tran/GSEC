import { useState } from 'react'

import { useRecordingSimulation } from '../../hooks/useRecordingSimulation'
import { ActionButton } from '../task/ActionButton'
import { TaskPanel } from '../task/TaskPanel'
import { RecordingTimer } from './RecordingTimer'
import { TranscriptConfirmation } from './TranscriptConfirmation'
import { Waveform } from './Waveform'

interface RecordingCardProps {
  label: string
  range: string
  stage: string
  transcript: string
  demoLabel?: string
  recordLabel?: string
  recordingDurationMs?: number
  conversionDurationMs?: number
  onConfirm: () => void
}

export function RecordingCard({ label, range, stage, transcript, demoLabel = 'Demo', recordLabel = '🎙 Record', recordingDurationMs, conversionDurationMs, onConfirm }: RecordingCardProps) {
  const [heard, setHeard] = useState(false)
  const recording = useRecordingSimulation(() => setHeard(true), { recordingDurationMs, conversionDurationMs })
  const run = () => { setHeard(false); recording.start() }

  return (
    <TaskPanel title={label} subtitle={range} data-stage={stage}>
      <Waveform active={recording.status === 'recording'} />
      <RecordingTimer elapsed={recording.elapsed} />
      {!heard ? (
        <div className="actions">
          <ActionButton variant="secondary" className="btn secondary" data-demo disabled={recording.status !== 'idle'} onClick={run}>{demoLabel}</ActionButton>
          <ActionButton className="btn primary" data-record disabled={recording.status !== 'idle'} onClick={run}>
            {recording.status === 'recording' ? '● Recording...' : recording.status === 'converting' ? 'Converting to text...' : recordLabel}
          </ActionButton>
        </div>
      ) : (
        <TranscriptConfirmation
          transcript={transcript}
          onRetry={() => { setHeard(false); recording.reset() }}
          onConfirm={onConfirm}
        />
      )}
    </TaskPanel>
  )
}
