import type { TaskArchetype, TaskAuthoringSchema } from './schema'

const archetypes: Record<string, readonly TaskArchetype[]> = {
  '60111': ['answer-entry', 'retry-coaching'],
  '60112': ['listening', 'speech-recording', 'retry-coaching'],
  '60113': ['listening', 'choice-assessment', 'retry-coaching'],
  '60114': ['listening', 'choice-assessment', 'retry-coaching'],
  '60115': ['writing-repair', 'listening'],
  '60116': ['speech-recording', 'transcript-repair', 'retry-coaching'],
  '60121': ['answer-entry', 'retry-coaching'],
  '60122': ['choice-assessment', 'retry-coaching'],
  '60123': ['listening', 'choice-assessment', 'speech-recording'],
  '60124': ['speech-recording', 'transcript-repair'],
  '60125': ['speech-recording', 'transcript-repair'],
  '60126': ['choice-assessment', 'retry-coaching', 'mastery-review'],
  '60131': ['answer-entry', 'retry-coaching'],
  '60132': ['choice-assessment', 'retry-coaching'],
  '60133': ['choice-assessment', 'retry-coaching'],
  '60134': ['choice-assessment', 'retry-coaching'],
  '60135': ['speech-recording', 'transcript-repair', 'writing-repair'],
  '60141': ['answer-entry', 'retry-coaching'],
  '60142': ['choice-assessment', 'retry-coaching'],
  '60143': ['role-play', 'speech-recording', 'transcript-repair'],
  '60144': ['role-play', 'speech-recording', 'transcript-repair', 'mastery-review'],
  '60151': ['reading-comprehension', 'choice-assessment', 'retry-coaching'],
  '60152': ['reading-comprehension', 'choice-assessment', 'retry-coaching'],
  '60153': ['reading-comprehension', 'answer-entry', 'retry-coaching'],
  '60154': ['readiness-checklist'],
  '60155': ['role-play', 'speech-recording', 'transcript-repair', 'mastery-review'],
}

export const TASK_AUTHORING_SCHEMAS: Readonly<Record<string, TaskAuthoringSchema>> =
  Object.freeze(
    Object.fromEntries(
      Object.entries(archetypes).map(([code, taskArchetypes]) => [
        code,
        Object.freeze({ code, archetypes: Object.freeze([...taskArchetypes]), version: 1 as const }),
      ]),
    ),
  )

export function getTaskAuthoringSchema(code: string): TaskAuthoringSchema {
  const schema = TASK_AUTHORING_SCHEMAS[code]
  if (!schema) throw new Error(`Missing task authoring schema for ${code}`)
  return schema
}
